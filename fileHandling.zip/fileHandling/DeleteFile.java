package fileHandling;
import java.io.*;
import java.util.Scanner;
public class DeleteFile {

	public static void delete(){
		System.out.println("enter folder name:- ");
		Scanner scan= new Scanner(System.in);
		String file=scan.nextLine();
		File folder=new File("C:\\main\\"+file);
		if (folder.exists()) {
			try {
				folder.delete();
				System.out.println("DELETION SUCCESSFULL");
			}
			catch(Exception e) {
				System.out.println("ERROR");
			}
		}
		else {
			System.out.println("file not exists");
		}
	}

}
