package fileHandling;

import java.util.Scanner;

public class NextOptions {
			public static void option_is(int num) {
				Scanner scan=new Scanner(System.in);
				System.out.println("WELCOME AGAIN :) ");
				System.out.println("");
				System.out.println("PRESS :-");
				System.out.println("1. TO CREATE NEW FOLDER ");
				System.out.println("2. TO DELETE FILE");
				System.out.println("3. TO FIND THE FOLDER WITH STARTING NAME");
				System.out.println("4. RETURN TO MAIN MENU");
				System.out.println("5. TO TERMINATE THE PROGRAM");
				System.out.println("");
				System.out.println("ENETR YOUR OPTONS");
				int num2=scan.nextInt();
				
				if(num2==1) {
					AddFolder.add_Folder();
					System.out.println("");
					option_is(num);
				}
				else if(num2==2) {
					DeleteFile.delete();
					System.out.println("");
					option_is(num);
				}
				else if(num2==3) {
					MatchFile.match_File();
					System.out.println("");
					option_is(num);
				}
				else if (num2==4) {
					fileHandlingDemo.main_options();
				}
				else if(num2==5) {
					System.out.println("PROGRAM TERMINATED");
				}
				else {
					option_is(num);
				}
				
			}
}
