package fileHandling;

import java.io.File;
import java.util.Scanner;

public class fileHandlingDemo {
	public static void main_options() {
		Scanner scan = new Scanner(System.in);
		
		//CREATING A FOLDER//
		
		File folder=new File("C:\\main");
		folder.mkdirs();
		File files[]=folder.listFiles();
		System.out.println("WARM !!!  WELCOME");
		System.out.println("");
		System.out.println("PRESS:- ");
		System.out.println("1. TO RETRIVE ALL FILES INSIDE MAIN FOLDER AND DISPLAY IN ASSCENDING ORDER");
		System.out.println("2. TO PERFORN OTHER OPERATINS FROM TAKING USER INPUTS");
		System.out.println("3. TO TERMINATE THE PROGRAM");
		System.out.println("");
		System.out.println("ENTER YOUR OPTION");
		int num=0;
		try {
			num=scan.nextInt();
		}catch(Exception e) {
			System.out.println("ONLY INTEGERS ARE ALLOWED");
		}
		
		if (num==1) {
			try {
				for(File f:files) {
					System.out.println(f);
					System.out.println("");
					main_options();
				}
				
			}catch(Exception e) {
				System.out.println("ERROR in opening file");
			}
		}
		else if(num==2) {
				NextOptions.option_is(num);
		}
		else if(num==3) {
			System.out.println("PROGRAM TERMINATED");
			
		}
		else {
			System.out.println("WRONG INPUT! TRY AGAIN");
			main_options();
		}
		}
		public static void main(String args[]) {
			main_options();
		}
		
	}
	


