package fileHandling;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.jar.Attributes.Name;

public class MatchFile {
	public static void main(String[] args) {
		match_File();
	}
    public static void match_File(){
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter your folder starting name : ");
        String substring1 = scan.next();
        String substring = substring1.toUpperCase();
        File f = new File("C:\\main\\");
        
        List<String> filesContainingSubstring = new ArrayList<String>();

        if( f.exists() && f.isDirectory() )
        {
            String[] files = f.list(); 
            for( String fileName : files )
            {
            	
                if( fileName.toUpperCase().contains( substring ) ) 
                     filesContainingSubstring.add( fileName );
            }
        }

        for( String fileName : filesContainingSubstring )
        {
           System.out.println( fileName ); 
 
        }
     }
       
}
    




